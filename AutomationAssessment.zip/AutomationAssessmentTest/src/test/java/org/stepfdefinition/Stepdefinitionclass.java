package org.stepfdefinition;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.concurrent.TimeUnit;

import org.baseclass.BaseClass;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Stepdefinitionclass extends BaseClass {
	@Given("Launch the chrome browser and maximize the window")
	public void launch_the_chrome_browser_and_maximize_the_window() {
	    launchChrome();
	    maxWin();
	}

	@Given("Enter the proper url")
	public void enter_the_proper_url() {
	   passUrl("https://pos.com.my/send/ratecalculator");
	}

	@When("User want to enter malaysia as from country and enter the pincode")
	public void user_want_to_enter_malaysia_as_from_country_and_enter_the_pincode() {
	    driver.manage().timeouts().implicitlyWait(2000, TimeUnit.SECONDS);
		driver.findElement(By.xpath("(//input[@placeholder='Postcode'])[1]")).sendKeys("35600");
		driver.manage().timeouts().implicitlyWait(3000, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Select country']")).click();
	}

	@Then("User want to enter as to country ans leave the postcode empty")
	public void user_want_to_enter_as_to_country_ans_leave_the_postcode_empty() throws AWTException {
		driver.manage().timeouts().implicitlyWait(3000, TimeUnit.SECONDS);
	    driver.findElement(By.xpath("//small[text()='Cote d Ivoire - CI']")).click();

	    
	    
	}

	@Then("User want to enter the weight and press the calculator")
	public void user_want_to_enter_the_weight_and_press_the_calculator() throws InterruptedException {
		driver.findElement(By.xpath("(//input[@type='number'])[2]")).sendKeys("1");
		driver.findElement(By.xpath("//a[text()=' Calculate ']")).click();
		Thread.sleep(2000);
	}

	@Then("Close the browser")
	public void close_the_browser() {
	    //driver.close();
	}


}
