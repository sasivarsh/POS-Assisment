package org.baseclass;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class BaseClass {
	
	public static WebDriver driver;
	public static JavascriptExecutor js;

	// 1. launch Chrome Browser

	public static void launchChrome() {
	WebDriverManager.chromedriver().setup();
	driver = new ChromeDriver();

	}

	// 2. launch Firefox Browser

	public static void launchFirefox() {
	WebDriverManager.firefoxdriver().setup();
	driver = new FirefoxDriver();

	}

	// 3. launch Edge Browser

	public static void launchEdge() {
	WebDriverManager.edgedriver().setup();
	driver = new EdgeDriver();

	}

	// 4. get url

	public static void passUrl(String url) {
	driver.get(url);

	}

	// 5. Window Maximize

	public static void maxWin() {
	driver.manage().window().maximize();
	}

	// 6. Get Current Url

	public static void urlPrint() {

	String urlPrint = driver.getCurrentUrl();
	System.out.println(urlPrint);

	}
	
	// 29. Alert - Dismiss

		public static void dismissAlert() {
		Alert y = driver.switchTo().alert();
		y.dismiss();
		}

	// 7. Get Title

	public static void titlePrint() {
	String title = driver.getTitle();
	System.out.println(title);

	}

	// 8. Get WindowHandle

	public static void getParentWindowHandle() {
	String windowHandle = driver.getWindowHandle();
	System.out.println(windowHandle);

	}

	// 9. Get Window Handles

	public static void getAllWindowHandles() {
	Set<String> windowHandles = driver.getWindowHandles();
	for (String eachId : windowHandles) {
	System.out.println(eachId);

	}

	}

	// 10. Switch to New Window

	public static void switchIntoWindow() {
	String parentId = driver.getWindowHandle();
	Set<String> allWind = driver.getWindowHandles();

	for (String eachId : allWind) {
	if (parentId != eachId) {
	driver.switchTo().window(eachId);

	}

	}

	}
	public static void getParentWindow() {
		Set<String> windowhandles=driver.getWindowHandles();
		List<String> li=new ArrayList<String>(windowhandles);
		driver.switchTo().window(li.get(0));
	}
	public static void getChidWindow() {
		Set<String> windowhandles=driver.getWindowHandles();
		List<String> li=new ArrayList<String>(windowhandles);
		driver.switchTo().window(li.get(1));

	}
	public static void getSecondWindow() {
		Set<String> windowhandles=driver.getWindowHandles();
		List<String> li=new ArrayList<String>(windowhandles);
		driver.switchTo().window(li.get(2));
	}
	
	public static void getThirddWindow() {
		Set<String> windowhandles=driver.getWindowHandles();
		List<String> li=new ArrayList<String>(windowhandles);
		driver.switchTo().window(li.get(3));
	}

	// 11. Close Current Tab

	public static void closeCurrentTab() {

	driver.close();

	}

	// 12. Close Browser
	public static void closeBrowser() {
	driver.quit();
	}

	// 13. send Keys
	public static void sendKeysCall(WebElement ele, String passValue) {

	ele.sendKeys(passValue);

	}

	// 14. Click

	public static void click(WebElement ele) {

	ele.click();

	}

	// 15. Get Text

	public static String getText(WebElement ele) {
	return ele.getText();

	}
	// 40. Implicit Wait

			public static void implicitWaitt(int sec) {

			driver.manage().timeouts().implicitlyWait(sec, TimeUnit.SECONDS);

			}
			
			

			// 23. Robot - Enter

			public static void robotEnter() throws AWTException {

			Robot r = new Robot();
			r.keyPress(KeyEvent.VK_ENTER);
			r.keyRelease(KeyEvent.VK_ENTER);

			}

			// 24. Robot - Tab

			public static void robotTab() throws AWTException {

			Robot r = new Robot();
			r.keyPress(KeyEvent.VK_TAB);
			r.keyRelease(KeyEvent.VK_TAB);

			}

			// 25. Robot - Control + C

			public static void copy() throws AWTException {

			Robot r = new Robot();
			r.keyPress(KeyEvent.VK_CONTROL);
			r.keyPress(KeyEvent.VK_C);
			r.keyRelease(KeyEvent.VK_CONTROL);
			r.keyRelease(KeyEvent.VK_C);
			}

			// 26. Robot - Control + v

			public static void paste() throws AWTException {

			Robot r = new Robot();
			r.keyPress(KeyEvent.VK_CONTROL);
			r.keyPress(KeyEvent.VK_V);
			r.keyRelease(KeyEvent.VK_CONTROL);
			r.keyRelease(KeyEvent.VK_V);
			}

			// 27. Robot - Control + x

			public static void cut() throws AWTException {

			Robot r = new Robot();
			r.keyPress(KeyEvent.VK_CONTROL);
			r.keyPress(KeyEvent.VK_X);
			r.keyRelease(KeyEvent.VK_CONTROL);
			r.keyRelease(KeyEvent.VK_X);
			}

			// 28. Alert - accept

			public static void acceptAlert() {
			Alert y = driver.switchTo().alert();
			y.accept();
			}

			// 29. Alert - Dismiss

			public static void dismissAlert1() {
			Alert y = driver.switchTo().alert();
			y.dismiss();
			}

			// 29. Alert - Sendkeys

			public static void alertSendKeys(String value) {
			Alert y = driver.switchTo().alert();
			String text = y.getText();
			System.out.println(text);

			}


}



